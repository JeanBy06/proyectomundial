package proyectofinal.gui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentanaPrincipal extends JFrame {
//colores no borrar
    private static final long serialVersionUID = 1L;
    private static final Color AZUL_OSCURO   = new Color(0x0D, 0x1B, 0x3E);
    private static final Color AZUL_MEDIO    = new Color(0x1A, 0x33, 0x6B);
    private static final Color ROJO_FIFA     = new Color(0xE5, 0x00, 0x2B);
    private static final Color TEAL          = new Color(0x00, 0x84, 0x94);
    private static final Color DORADO        = new Color(0xFF, 0xC1, 0x07);
    private static final Color FONDO         = new Color(0xE8, 0xEA, 0xED);
    private static final Color BLANCO        = Color.WHITE;
    private static final Color GRIS_TEXTO    = new Color(0x99, 0xAA, 0xBB);
    private static final Color TAB_SEL       = new Color(0xC6, 0x28, 0x28);
    private static final Color TAB_UNSEL     = new Color(0x0D, 0x1B, 0x3E);
    private static final Color TAB_HOVER     = new Color(0x15, 0x28, 0x52);

    private JTabbedPane tabbedPane;
    private JLabel lblEstado;

    public VentanaPrincipal() {
        setTitle("FIFA World Cup 2026 - Analisis Tactico y Posesion");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1300, 800);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        initUI();
        conectarBD();
    }

    private void initUI() {
        UIManager.put("TabbedPane.selected", TAB_SEL);
        UIManager.put("TabbedPane.background", TAB_UNSEL);
        UIManager.put("TabbedPane.foreground", BLANCO);
        UIManager.put("TabbedPane.selectedForeground", BLANCO);
        UIManager.put("TabbedPane.tabAreaBackground", AZUL_OSCURO);
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.tabsOverlapBorder", true);
        UIManager.put("TabbedPane.tabInsets", new Insets(6, 10, 6, 10));

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(FONDO);

        panelPrincipal.add(crearBarraSuperior(), BorderLayout.NORTH);

        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabbedPane.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        String[] tabs = {"SELECCIONES", "PARTIDOS", "FORMACIONES", "ZONAS", "ESTADISTICAS", "RESUMEN", "HISTORIAL"};
        JPanel[] paneles = {
            crearPanelSelecciones(), crearPanelPartidos(), crearPanelFormaciones(),
            crearPanelZonas(), crearPanelEstadisticas(), crearPanelResumen(), crearPanelHistorial()
        };

        for (int i = 0; i < tabs.length; i++) {
            tabbedPane.addTab("", paneles[i]);
            tabbedPane.setTabComponentAt(i, crearTabHeader(tabs[i], i == 0));
        }

        tabbedPane.addChangeListener(e -> {
            int idx = tabbedPane.getSelectedIndex();
            for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                Component c = tabbedPane.getTabComponentAt(i);
                if (c instanceof JPanel) {
                    JPanel p = (JPanel) c;
                    p.setBackground(i == idx ? TAB_SEL : TAB_UNSEL);
                    for (Component comp : p.getComponents()) {
                        if (comp instanceof JLabel) {
                            comp.setForeground(i == idx ? DORADO : BLANCO);
                        }
                    }
                }
            }
        });

        panelPrincipal.add(tabbedPane, BorderLayout.CENTER);
        panelPrincipal.add(crearBarraEstado(), BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private JPanel crearTabHeader(String texto, boolean selected) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        panel.setOpaque(true);
        panel.setBackground(selected ? TAB_SEL : TAB_UNSEL);
        panel.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(selected ? DORADO : BLANCO);
        panel.add(label);
        return panel;
    }

    private JPanel crearSubTabHeader(String texto, boolean selected) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        panel.setOpaque(true);
        panel.setBackground(selected ? TAB_SEL : TEAL);
        panel.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Segoe UI", Font.BOLD, 11));
        label.setForeground(selected ? DORADO : BLANCO);
        panel.add(label);
        return panel;
    }

    private JPanel crearBarraSuperior() {
        JPanel barra = new JPanel(new BorderLayout());
        barra.setBackground(AZUL_OSCURO);
        barra.setPreferredSize(new Dimension(0, 72));
        barra.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));

        JLabel titulo = new JLabel("MUNDIAL FIFA 2026");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(BLANCO);
        barra.add(titulo, BorderLayout.WEST);

        JLabel subtitulo = new JLabel("Analisis Tactico y Posesion");
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitulo.setForeground(DORADO);
        barra.add(subtitulo, BorderLayout.EAST);

        JPanel lineaRoja = new JPanel();
        lineaRoja.setBackground(ROJO_FIFA);
        lineaRoja.setPreferredSize(new Dimension(0, 4));
        JPanel contenedor = new JPanel(new BorderLayout());
        contenedor.add(barra, BorderLayout.CENTER);
        contenedor.add(lineaRoja, BorderLayout.SOUTH);
        return contenedor;
    }

    private JPanel crearBarraEstado() {
        JPanel barra = new JPanel(new BorderLayout());
        barra.setBackground(AZUL_OSCURO);
        barra.setBorder(BorderFactory.createEmptyBorder(4, 16, 4, 16));

        lblEstado = new JLabel("Conectando a la base de datos...");
        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblEstado.setForeground(BLANCO);

        JLabel lblCreditos = new JLabel("FIFA World Cup 2026 - MS-3");
        lblCreditos.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblCreditos.setForeground(GRIS_TEXTO);

        barra.add(lblEstado, BorderLayout.WEST);
        barra.add(lblCreditos, BorderLayout.EAST);
        return barra;
    }

    private void conectarBD() {
        try {
            Connection c = proyectofinal.db.ConexionBD.getConexion();
            if (c != null && !c.isClosed()) {
                lblEstado.setText("Conectado a PostgreSQL - mundial_ms3");
                lblEstado.setForeground(new Color(0x4C, 0xAF, 0x50));
            } else {
                lblEstado.setText("Sin conexion a la base de datos");
                lblEstado.setForeground(ROJO_FIFA);
            }
        } catch (Exception e) {
            lblEstado.setText("Error de conexion: " + e.getMessage());
            lblEstado.setForeground(ROJO_FIFA);
        }
    }

    private JScrollPane crearTabla(String sql, String[] columnas) {
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        try {
            Connection conn = proyectofinal.db.ConexionBD.getConexion();
            if (conn == null) throw new SQLException("Conexion nula");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    Object[] fila = new Object[columnas.length];
                    for (int i = 0; i < columnas.length; i++) {
                        fila[i] = rs.getObject(i + 1);
                    }
                    modelo.addRow(fila);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al consultar: " + e.getMessage(),
                    "Error BD", JOptionPane.ERROR_MESSAGE);
        }

        JTable tabla = new JTable(modelo);
        tabla.setFont(new Font("Consolas", Font.PLAIN, 12));
        tabla.setRowHeight(26);
        tabla.setGridColor(new Color(0xE0, 0xE0, 0xE0));
        tabla.setBackground(BLANCO);
        tabla.setSelectionBackground(new Color(0xBB, 0xDE, 0xFB));
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JTableHeader header = tabla.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(AZUL_OSCURO);
        header.setForeground(BLANCO);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, ROJO_FIFA));

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(0xDD, 0xDD, 0xDD)));
        scroll.getViewport().setBackground(BLANCO);
        return scroll;
    }

    private JScrollPane crearTablaConParametros(String sql, String[] columnas, Object... params) {
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        try {
            Connection conn = proyectofinal.db.ConexionBD.getConexion();
            if (conn == null) throw new SQLException("Conexion nula");
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                for (int i = 0; i < params.length; i++) {
                    stmt.setObject(i + 1, params[i]);
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Object[] fila = new Object[columnas.length];
                        for (int i = 0; i < columnas.length; i++) {
                            fila[i] = rs.getObject(i + 1);
                        }
                        modelo.addRow(fila);
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(),
                    "Error BD", JOptionPane.ERROR_MESSAGE);
        }

        JTable tabla = new JTable(modelo);
        tabla.setFont(new Font("Consolas", Font.PLAIN, 12));
        tabla.setRowHeight(26);
        tabla.setGridColor(new Color(0xE0, 0xE0, 0xE0));
        tabla.setBackground(BLANCO);
        tabla.setSelectionBackground(new Color(0xBB, 0xDE, 0xFB));

        JTableHeader header = tabla.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(AZUL_OSCURO);
        header.setForeground(BLANCO);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(0xDD, 0xDD, 0xDD)));
        scroll.getViewport().setBackground(BLANCO);
        return scroll;
    }

    private JPanel crearPanelSelecciones() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Selecciones Participantes - Mundial 2026");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(AZUL_OSCURO);
        panel.add(titulo, BorderLayout.NORTH);

        String[] cols = {"ID", "Nombre", "FIFA", "Confederacion", "Continente", "Grupo", "Ranking"};
        String sqlBase = "SELECT seleccion_id, nombre, codigo_fifa, confederacion, continente, grupo_asignado, ranking_fifa " +
                         "FROM seleccion_ref";
        JScrollPane scroll = crearTabla(sqlBase + " ORDER BY grupo_asignado, nombre", cols);
        panel.add(scroll, BorderLayout.CENTER);

        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filtros.setBackground(FONDO);

        JLabel lblBuscar = new JLabel("Buscar por nombre:");
        lblBuscar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        filtros.add(lblBuscar);

        JTextField txtBuscar = new JTextField(15);
        txtBuscar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        filtros.add(txtBuscar);

        JLabel lbl = new JLabel("Confederacion:");
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        filtros.add(lbl);

        String[] confs = {"Todas", "UEFA", "CAF", "AFC", "CONCACAF", "CONMEBOL", "OFC"};
        JComboBox<String> cmbConf = new JComboBox<>(confs);
        cmbConf.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        Runnable actualizar = () -> {
            String nombre = txtBuscar.getText().trim();
            String conf = (String) cmbConf.getSelectedItem();
            StringBuilder q = new StringBuilder(sqlBase);
            boolean whereAdded = false;
            if (!nombre.isEmpty()) {
                q.append(" WHERE LOWER(nombre) LIKE ?");
                whereAdded = true;
            }
            if (!"Todas".equals(conf)) {
                q.append(whereAdded ? " AND" : " WHERE").append(" confederacion = ?");
            }
            q.append(" ORDER BY grupo_asignado, nombre");
            panel.remove(1);
            Object[] params;
            int idx = 0;
            if (!nombre.isEmpty() && !"Todas".equals(conf)) {
                params = new Object[]{"%" + nombre.toLowerCase() + "%", conf};
            } else if (!nombre.isEmpty()) {
                params = new Object[]{"%" + nombre.toLowerCase() + "%"};
            } else if (!"Todas".equals(conf)) {
                params = new Object[]{conf};
            } else {
                params = new Object[]{};
            }
            if (params.length > 0) {
                panel.add(crearTablaConParametros(q.toString(), cols, params), BorderLayout.CENTER);
            } else {
                panel.add(crearTabla(q.toString(), cols), BorderLayout.CENTER);
            }
            panel.revalidate();
            panel.repaint();
        };

        txtBuscar.addActionListener(e -> actualizar.run());
        cmbConf.addActionListener(e -> actualizar.run());
        filtros.add(cmbConf);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBuscar.setBackground(AZUL_MEDIO);
        btnBuscar.setForeground(BLANCO);
        btnBuscar.addActionListener(e -> actualizar.run());
        filtros.add(btnBuscar);

        panel.add(filtros, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel crearPanelPartidos() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Calendario de Partidos - Fase de Grupos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(AZUL_OSCURO);
        panel.add(titulo, BorderLayout.NORTH);

        String sql = "SELECT p.partido_id, l.nombre AS local, v.nombre AS visitante, " +
                     "p.fecha_hora::date AS fecha, p.fase, p.grupo_letra, p.jornada " +
                     "FROM partido_ref p " +
                     "JOIN seleccion_ref l ON l.seleccion_id = p.local_id " +
                     "JOIN seleccion_ref v ON v.seleccion_id = p.visitante_id " +
                     "ORDER BY p.partido_id";
        String[] cols = {"ID", "Local", "Visitante", "Fecha", "Fase", "Grupo", "Jornada"};

        panel.add(crearTabla(sql, cols), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelFormaciones() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Catalogo de Formaciones Tacticas");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(AZUL_OSCURO);
        panel.add(titulo, BorderLayout.NORTH);

        String sql = "SELECT formacion_id, esquema, descripcion, tipo_juego, " +
                     "num_defensas, num_medios, num_delanteros, ventajas, desventajas " +
                     "FROM formacion_catalogo ORDER BY formacion_id";
        String[] cols = {"ID", "Esquema", "Descripcion", "Tipo", "Def", "Med", "Del", "Ventajas", "Desventajas"};

        panel.add(crearTabla(sql, cols), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelZonas() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Zonas del Campo");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(AZUL_OSCURO);
        panel.add(titulo, BorderLayout.NORTH);

        String sql = "SELECT zona_id, nombre, descripcion, es_area_penal, es_zona_local, orden_campo, distancia_ref_m " +
                     "FROM zona_campo ORDER BY orden_campo";
        String[] cols = {"ID", "Nombre", "Descripcion", "Area Penal", "Zona Local", "Orden", "Distancia (m)"};

        panel.add(crearTabla(sql, cols), BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelEstadisticas() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Gestion de Estadisticas");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(AZUL_OSCURO);
        panel.add(titulo, BorderLayout.NORTH);

        JTabbedPane subTabs = new JTabbedPane();
        subTabs.setFont(new Font("Segoe UI", Font.BOLD, 12));
        subTabs.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        String[] stabs = {"CARGAR ESTADISTICAS", "REGISTRAR CORNER", "REGISTRAR TIRO LIBRE", "REGISTRAR FALTA", "VER DATOS"};
        JPanel[] spaneles = {
            crearFormCargarEstadisticas(), crearFormCorner(),
            crearFormTiroLibre(), crearFormFalta(), crearPanelVerEstadisticas()
        };

        for (int i = 0; i < stabs.length; i++) {
            subTabs.addTab("", spaneles[i]);
            subTabs.setTabComponentAt(i, crearSubTabHeader(stabs[i], i == 0));
        }

        subTabs.addChangeListener(e -> {
            int idx = subTabs.getSelectedIndex();
            for (int i = 0; i < subTabs.getTabCount(); i++) {
                Component c = subTabs.getTabComponentAt(i);
                if (c instanceof JPanel) {
                    JPanel p = (JPanel) c;
                    p.setBackground(i == idx ? TAB_SEL : TEAL);
                    for (Component comp : p.getComponents()) {
                        if (comp instanceof JLabel) {
                            comp.setForeground(i == idx ? DORADO : BLANCO);
                        }
                    }
                }
            }
        });

        panel.add(subTabs, BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelVerEstadisticas() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        String sql = "SELECT ep.estadistica_id, ep.partido_id, s.nombre, " +
                     "ep.posesion_pct, ep.tiros_al_arco, ep.tiros_fuera, " +
                     "ep.corners, ep.faltas_cometidas, ep.pases_completados, " +
                     "ep.tiros_libres, ep.tarjetas_amarillas, ep.tarjetas_rojas " +
                     "FROM estadistica_partido ep " +
                     "JOIN seleccion_ref s ON s.seleccion_id = ep.seleccion_id " +
                     "ORDER BY ep.partido_id";
        String[] cols = {"ID", "Partido", "Seleccion", "Posesion%", "Tiros Arco", "Tiros Fuera",
                         "Corners", "Faltas", "Pases OK", "TL", "Amarillas", "Rojas"};

        panel.add(crearTabla(sql, cols), BorderLayout.CENTER);
        return panel;
    }

    private JComboBox<String> crearComboConBusqueda() {
        JComboBox<String> combo = new JComboBox<>();
        combo.setEditable(true);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        return combo;
    }

    private void configurarBusqueda(JComboBox<String> combo, List<String> todos) {
        JTextField editor = (JTextField) combo.getEditor().getEditorComponent();
        editor.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        editor.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String texto = editor.getText().toLowerCase().trim();
                combo.removeAllItems();
                if (texto.isEmpty()) {
                    for (String item : todos) combo.addItem(item);
                } else {
                    for (String item : todos) {
                        if (item.toLowerCase().contains(texto)) combo.addItem(item);
                    }
                }
                if (combo.getItemCount() > 0 && !combo.isPopupVisible()) combo.showPopup();
                if (combo.getItemCount() > 0) {
                    combo.setSelectedItem(null);
                    for (int i = 0; i < combo.getItemCount(); i++) {
                        if (combo.getItemAt(i).toLowerCase().contains(texto)) {
                            combo.setSelectedIndex(i); break;
                        }
                    }
                }
            }
        });
        editor.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                if (editor.getText().trim().isEmpty() && !todos.isEmpty()) {
                    combo.removeAllItems();
                    for (String item : todos) combo.addItem(item);
                }
            }
        });
        for (String item : todos) combo.addItem(item);
    }

    private void llenarComboPartidos(JComboBox<String> combo) {
        List<String> items = new ArrayList<>();
        try {
            Connection conn = proyectofinal.db.ConexionBD.getConexion();
            String sql = "SELECT p.partido_id, l.nombre || ' vs ' || v.nombre AS partido " +
                         "FROM partido_ref p JOIN seleccion_ref l ON l.seleccion_id = p.local_id " +
                         "JOIN seleccion_ref v ON v.seleccion_id = p.visitante_id ORDER BY p.partido_id";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    items.add(rs.getInt("partido_id") + " - " + rs.getString("partido"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar partidos: " + e.getMessage());
        }
        configurarBusqueda(combo, items);
    }

    private void llenarComboSelecciones(JComboBox<String> combo) {
        List<String> items = new ArrayList<>();
        try {
            Connection conn = proyectofinal.db.ConexionBD.getConexion();
            String sql = "SELECT seleccion_id, nombre FROM seleccion_ref ORDER BY nombre";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    items.add(rs.getInt("seleccion_id") + " - " + rs.getString("nombre"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar selecciones: " + e.getMessage());
        }
        configurarBusqueda(combo, items);
    }

    private void llenarComboZonas(JComboBox<String> combo) {
        List<String> items = new ArrayList<>();
        try {
            Connection conn = proyectofinal.db.ConexionBD.getConexion();
            String sql = "SELECT zona_id, nombre FROM zona_campo ORDER BY orden_campo";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    items.add(rs.getInt("zona_id") + " - " + rs.getString("nombre"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar zonas: " + e.getMessage());
        }
        configurarBusqueda(combo, items);
    }

    private JPanel crearFormCargarEstadisticas() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(BLANCO);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xDD, 0xDD, 0xDD)),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 8, 4, 8);

        JComboBox<String> cmbPartido = new JComboBox<String>();
        llenarComboPartidos(cmbPartido);

        JComboBox<String> cmbSeleccion = new JComboBox<String>();
        llenarComboSelecciones(cmbSeleccion);

        JSpinner spPosesion = new JSpinner(new SpinnerNumberModel(50.0, 0.0, 100.0, 0.5));
        JSpinner spTirosArco = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
        JSpinner spTirosFuera = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
        JSpinner spTirosBloq = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
        JSpinner spCorners = new JSpinner(new SpinnerNumberModel(0, 0, 30, 1));
        JSpinner spTirosLibres = new JSpinner(new SpinnerNumberModel(0, 0, 30, 1));
        JSpinner spFaltas = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
        JSpinner spPasesTot = new JSpinner(new SpinnerNumberModel(0, 0, 1500, 10));
        JSpinner spPasesCom = new JSpinner(new SpinnerNumberModel(0, 0, 1500, 10));
        JSpinner spSalvadas = new JSpinner(new SpinnerNumberModel(0, 0, 30, 1));
        JSpinner spDespejes = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
        JSpinner spAmarillas = new JSpinner(new SpinnerNumberModel(0, 0, 10, 1));
        JSpinner spRojas = new JSpinner(new SpinnerNumberModel(0, 0, 5, 1));

        Font f = new Font("Segoe UI", Font.PLAIN, 13);
        JLabel[] labels = {
            new JLabel("Partido:"), new JLabel("Seleccion:"),
            new JLabel("Posesion %:"), new JLabel("Tiros al Arco:"),
            new JLabel("Tiros Fuera:"), new JLabel("Tiros Bloqueados:"),
            new JLabel("Corners:"), new JLabel("Tiros Libres:"),
            new JLabel("Faltas Cometidas:"), new JLabel("Pases Totales:"),
            new JLabel("Pases Completados:"), new JLabel("Salvadas:"),
            new JLabel("Despejes:"), new JLabel("Tarjetas Amarillas:"),
            new JLabel("Tarjetas Rojas:")
        };
        for (JLabel l : labels) l.setFont(f);

        JComponent[] campos = {
            cmbPartido, cmbSeleccion, spPosesion, spTirosArco, spTirosFuera,
            spTirosBloq, spCorners, spTirosLibres, spFaltas, spPasesTot,
            spPasesCom, spSalvadas, spDespejes, spAmarillas, spRojas
        };

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            gbc.weightx = 0.0;
            if (i == 0) gbc.gridy = i / 2;
            else if (i < 4) gbc.gridy = i;
            form.add(labels[i], gbc);
            gbc.gridx = 1; gbc.weightx = 1.0;
            form.add(campos[i], gbc);
        }

        JButton btnGuardar = new JButton("Cargar Estadisticas");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(AZUL_OSCURO);
        btnGuardar.setForeground(BLANCO);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        btnGuardar.addActionListener(e -> {
            try {
                Connection conn = proyectofinal.db.ConexionBD.getConexion();
                CallableStatement cs = conn.prepareCall("{call sp_cargar_estadisticas(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
                cs.setInt(1, extraerId((String) cmbPartido.getSelectedItem()));
                cs.setInt(2, extraerId((String) cmbSeleccion.getSelectedItem()));
                cs.setDouble(3, (Double) spPosesion.getValue());
                cs.setInt(4, (Integer) spTirosArco.getValue());
                cs.setInt(5, (Integer) spTirosFuera.getValue());
                cs.setInt(6, (Integer) spTirosBloq.getValue());
                cs.setInt(7, (Integer) spCorners.getValue());
                cs.setInt(8, (Integer) spTirosLibres.getValue());
                cs.setInt(9, (Integer) spFaltas.getValue());
                cs.setInt(10, (Integer) spPasesTot.getValue());
                cs.setInt(11, (Integer) spPasesCom.getValue());
                cs.setInt(12, (Integer) spSalvadas.getValue());
                cs.setInt(13, (Integer) spDespejes.getValue());
                cs.setInt(14, (Integer) spAmarillas.getValue());
                cs.setInt(15, (Integer) spRojas.getValue());
                cs.execute();
                JOptionPane.showMessageDialog(this, "Estadisticas cargadas correctamente!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel botonera = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botonera.setBackground(FONDO);
        botonera.add(btnGuardar);

        panel.add(form, BorderLayout.CENTER);
        panel.add(botonera, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel crearFormCorner() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(BLANCO);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xDD, 0xDD, 0xDD)),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 8, 4, 8);

        JComboBox<String> cmbPartido = new JComboBox<String>();
        llenarComboPartidos(cmbPartido);

        JComboBox<String> cmbSeleccion = new JComboBox<String>();
        llenarComboSelecciones(cmbSeleccion);

        JSpinner spMinuto = new JSpinner(new SpinnerNumberModel(1, 1, 130, 1));

        JComboBox<String> cmbZona = new JComboBox<String>();
        llenarComboZonas(cmbZona);

        String[] resultados = {"gol", "tiro_arco", "despeje", "sin_remate", "fuera", "otro_corner"};
        JComboBox<String> cmbResultado = new JComboBox<>(resultados);
        cmbResultado.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        String[] lados = {"derecho", "izquierdo"};
        JComboBox<String> cmbLado = new JComboBox<>(lados);
        cmbLado.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JComboBox<String> cmbGolDirecto = new JComboBox<>(new String[]{"No", "Si"});
        cmbGolDirecto.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        Font f = new Font("Segoe UI", Font.PLAIN, 13);
        JLabel[] labels = {
            new JLabel("Partido:"), new JLabel("Seleccion:"),
            new JLabel("Minuto:"), new JLabel("Zona Destino:"),
            new JLabel("Resultado:"), new JLabel("Lado Ejecucion:"),
            new JLabel("Gol Directo:")
        };
        for (JLabel l : labels) l.setFont(f);

        JComponent[] campos = {cmbPartido, cmbSeleccion, spMinuto, cmbZona, cmbResultado, cmbLado, cmbGolDirecto};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.0;
            form.add(labels[i], gbc);
            gbc.gridx = 1; gbc.weightx = 1.0;
            form.add(campos[i], gbc);
        }

        JButton btnGuardar = new JButton("Registrar Corner");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(AZUL_OSCURO);
        btnGuardar.setForeground(BLANCO);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        btnGuardar.addActionListener(e -> {
            try {
                Connection conn = proyectofinal.db.ConexionBD.getConexion();
                CallableStatement cs = conn.prepareCall("{call sp_registrar_corner(?,?,?,?,?,?,?)}");
                cs.setInt(1, extraerId((String) cmbPartido.getSelectedItem()));
                cs.setInt(2, extraerId((String) cmbSeleccion.getSelectedItem()));
                cs.setInt(3, (Integer) spMinuto.getValue());
                cs.setInt(4, extraerId((String) cmbZona.getSelectedItem()));
                cs.setString(5, (String) cmbResultado.getSelectedItem());
                cs.setString(6, (String) cmbLado.getSelectedItem());
                cs.setBoolean(7, "Si".equals(cmbGolDirecto.getSelectedItem()));
                cs.execute();
                JOptionPane.showMessageDialog(this, "Corner registrado correctamente!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel botonera = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botonera.setBackground(FONDO);
        botonera.add(btnGuardar);

        panel.add(form, BorderLayout.CENTER);
        panel.add(botonera, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel crearFormTiroLibre() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(BLANCO);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xDD, 0xDD, 0xDD)),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 8, 4, 8);

        JComboBox<String> cmbPartido = new JComboBox<String>();
        llenarComboPartidos(cmbPartido);

        JComboBox<String> cmbSeleccion = new JComboBox<String>();
        llenarComboSelecciones(cmbSeleccion);

        JSpinner spMinuto = new JSpinner(new SpinnerNumberModel(1, 1, 130, 1));
        JSpinner spDistancia = new JSpinner(new SpinnerNumberModel(20.0, 1.0, 60.0, 0.5));

        String[] resultados = {"gol", "al_arco", "fuera", "barrera", "robado", "asistencia"};
        JComboBox<String> cmbResultado = new JComboBox<>(resultados);
        cmbResultado.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JComboBox<String> cmbDirecto = new JComboBox<>(new String[]{"No", "Si"});
        cmbDirecto.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        Font f = new Font("Segoe UI", Font.PLAIN, 13);
        JLabel[] labels = {
            new JLabel("Partido:"), new JLabel("Seleccion:"),
            new JLabel("Minuto:"), new JLabel("Distancia (m):"),
            new JLabel("Resultado:"), new JLabel("Tiro Directo:")
        };
        for (JLabel l : labels) l.setFont(f);

        JComponent[] campos = {cmbPartido, cmbSeleccion, spMinuto, spDistancia, cmbResultado, cmbDirecto};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.0;
            form.add(labels[i], gbc);
            gbc.gridx = 1; gbc.weightx = 1.0;
            form.add(campos[i], gbc);
        }

        JButton btnGuardar = new JButton("Registrar Tiro Libre");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(AZUL_OSCURO);
        btnGuardar.setForeground(BLANCO);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        btnGuardar.addActionListener(e -> {
            try {
                Connection conn = proyectofinal.db.ConexionBD.getConexion();
                CallableStatement cs = conn.prepareCall("{call sp_registrar_tiro_libre(?,?,?,?,?,?)}");
                cs.setInt(1, extraerId((String) cmbPartido.getSelectedItem()));
                cs.setInt(2, extraerId((String) cmbSeleccion.getSelectedItem()));
                cs.setInt(3, (Integer) spMinuto.getValue());
                cs.setDouble(4, (Double) spDistancia.getValue());
                cs.setString(5, (String) cmbResultado.getSelectedItem());
                cs.setBoolean(6, "Si".equals(cmbDirecto.getSelectedItem()));
                cs.execute();
                JOptionPane.showMessageDialog(this, "Tiro libre registrado correctamente!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel botonera = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botonera.setBackground(FONDO);
        botonera.add(btnGuardar);

        panel.add(form, BorderLayout.CENTER);
        panel.add(botonera, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel crearFormFalta() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(BLANCO);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xDD, 0xDD, 0xDD)),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 8, 4, 8);

        JComboBox<String> cmbPartido = new JComboBox<String>();
        llenarComboPartidos(cmbPartido);

        JComboBox<String> cmbCometio = new JComboBox<String>();
        llenarComboSelecciones(cmbCometio);

        JComboBox<String> cmbRecibio = new JComboBox<String>();
        llenarComboSelecciones(cmbRecibio);

        JComboBox<String> cmbZona = new JComboBox<String>();
        llenarComboZonas(cmbZona);

        JSpinner spMinuto = new JSpinner(new SpinnerNumberModel(1, 1, 130, 1));

        String[] gravedades = {"leve", "media", "grave"};
        JComboBox<String> cmbGravedad = new JComboBox<>(gravedades);
        cmbGravedad.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JComboBox<String> cmbTarjeta = new JComboBox<>(new String[]{"No", "Si"});
        cmbTarjeta.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JComboBox<String> cmbPenal = new JComboBox<>(new String[]{"No", "Si"});
        cmbPenal.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JComboBox<String> cmbVar = new JComboBox<>(new String[]{"No", "Si"});
        cmbVar.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        Font f = new Font("Segoe UI", Font.PLAIN, 13);
        JLabel[] labels = {
            new JLabel("Partido:"), new JLabel("Seleccion que Cometio:"),
            new JLabel("Seleccion que Recibio:"), new JLabel("Zona del Campo:"),
            new JLabel("Minuto:"), new JLabel("Gravedad:"),
            new JLabel("Derivo Tarjeta:"), new JLabel("Derivo Penal:"),
            new JLabel("Intervino VAR:")
        };
        for (JLabel l : labels) l.setFont(f);

        JComponent[] campos = {cmbPartido, cmbCometio, cmbRecibio, cmbZona, spMinuto,
                               cmbGravedad, cmbTarjeta, cmbPenal, cmbVar};

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.0;
            form.add(labels[i], gbc);
            gbc.gridx = 1; gbc.weightx = 1.0;
            form.add(campos[i], gbc);
        }

        JButton btnGuardar = new JButton("Registrar Falta");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(AZUL_OSCURO);
        btnGuardar.setForeground(BLANCO);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        btnGuardar.addActionListener(e -> {
            try {
                int min = (Integer) spMinuto.getValue();
                String tiempo;
                if (min <= 45) tiempo = "1T";
                else if (min <= 90) tiempo = "2T";
                else if (min <= 105) tiempo = "PT1";
                else tiempo = "PT2";
                Connection conn = proyectofinal.db.ConexionBD.getConexion();
                String sql = "INSERT INTO detalle_falta (partido_id, seleccion_cometio, seleccion_recibio, " +
                             "zona_campo_id, minuto, tiempo, gravedad, derivo_tarjeta, derivo_penal, fue_var) " +
                             "VALUES (?,?,?,?,?,?,?,?,?,?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, extraerId((String) cmbPartido.getSelectedItem()));
                    ps.setInt(2, extraerId((String) cmbCometio.getSelectedItem()));
                    ps.setInt(3, extraerId((String) cmbRecibio.getSelectedItem()));
                    ps.setInt(4, extraerId((String) cmbZona.getSelectedItem()));
                    ps.setInt(5, min);
                    ps.setString(6, tiempo);
                    ps.setString(7, (String) cmbGravedad.getSelectedItem());
                    ps.setBoolean(8, "Si".equals(cmbTarjeta.getSelectedItem()));
                    ps.setBoolean(9, "Si".equals(cmbPenal.getSelectedItem()));
                    ps.setBoolean(10, "Si".equals(cmbVar.getSelectedItem()));
                    ps.executeUpdate();
                }
                JOptionPane.showMessageDialog(this, "Falta registrada correctamente!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel botonera = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botonera.setBackground(FONDO);
        botonera.add(btnGuardar);

        panel.add(form, BorderLayout.CENTER);
        panel.add(botonera, BorderLayout.SOUTH);
        return panel;
    }

    private int extraerId(String texto) {
        if (texto == null || texto.isEmpty()) return -1;
        return Integer.parseInt(texto.split(" - ")[0]);
    }

    private JPanel crearPanelResumen() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel pestañasResumen = new JPanel(new BorderLayout());
        JTabbedPane subTabs = new JTabbedPane();
        subTabs.setFont(new Font("Segoe UI", Font.BOLD, 12));
        subTabs.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        String sqlSel = "SELECT r.seleccion_id, s.nombre, r.partidos, r.posesion_prom, " +
                        "r.corners_prom, r.precision_pases_pct, r.tiros_prom, " +
                        "r.faltas_prom, r.score_tactico " +
                        "FROM resumen_tactica_seleccion r " +
                        "JOIN seleccion_ref s ON s.seleccion_id = r.seleccion_id " +
                        "ORDER BY r.score_tactico DESC";
        String[] colsSel = {"ID", "Seleccion", "PJ", "Posesion", "Corners", "Prec. Pases", "Tiros", "Faltas", "Score Tactico"};
        subTabs.addTab("", crearTabla(sqlSel, colsSel));
        subTabs.setTabComponentAt(0, crearSubTabHeader("POR SELECCION", true));

        String sqlConf = "SELECT confederacion, selecciones_activas, partidos_totales, " +
                         "posesion_prom, corners_prom, precision_pases_pct, tiros_prom, faltas_prom " +
                         "FROM resumen_tactica_confederacion ORDER BY posesion_prom DESC";
        String[] colsConf = {"Confederacion", "Sel. Activas", "Partidos", "Posesion", "Corners", "Prec. Pases", "Tiros", "Faltas"};
        subTabs.addTab("", crearTabla(sqlConf, colsConf));
        subTabs.setTabComponentAt(1, crearSubTabHeader("POR CONFEDERACION", false));

        String sqlCont = "SELECT continente, selecciones, partidos_jugados, " +
                         "posesion_prom, corners_prom, precision_pases_pct, goles_prom, tiros_prom " +
                         "FROM resumen_tactica_continente ORDER BY posesion_prom DESC";
        String[] colsCont = {"Continente", "Selecciones", "Partidos", "Posesion", "Corners", "Prec. Pases", "Goles", "Tiros"};
        subTabs.addTab("", crearTabla(sqlCont, colsCont));
        subTabs.setTabComponentAt(2, crearSubTabHeader("POR CONTINENTE", false));

        String sqlMun = "SELECT partidos_jugados, total_goles, prom_goles_partido, " +
                        "total_corners, prom_corners_partido, total_faltas, " +
                        "total_amarillas, total_rojas, posesion_media_local " +
                        "FROM resumen_tactica_mundial WHERE mundial_id = 2026";
        String[] colsMun = {"Partidos", "Goles", "Prom. Goles", "Corners", "Prom. Corners",
                            "Faltas", "Amarillas", "Rojas", "Posesion Local"};
        subTabs.addTab("", crearTabla(sqlMun, colsMun));
        subTabs.setTabComponentAt(3, crearSubTabHeader("MUNDIAL", false));

        subTabs.addChangeListener(e -> {
            int idx = subTabs.getSelectedIndex();
            for (int i = 0; i < subTabs.getTabCount(); i++) {
                Component c = subTabs.getTabComponentAt(i);
                if (c instanceof JPanel) {
                    JPanel p = (JPanel) c;
                    p.setBackground(i == idx ? TAB_SEL : TEAL);
                    for (Component comp : p.getComponents()) {
                        if (comp instanceof JLabel) {
                            comp.setForeground(i == idx ? DORADO : BLANCO);
                        }
                    }
                }
            }
        });

        pestañasResumen.add(subTabs, BorderLayout.CENTER);
        panel.add(pestañasResumen, BorderLayout.CENTER);
        return panel;
    }

    private JPanel crearPanelHistorial() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel titulo = new JLabel("Comparativa Historica Tactica (Qatar 2022 / Rusia 2018)");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(AZUL_OSCURO);
        panel.add(titulo, BorderLayout.NORTH);

        String sql = "SELECT c.seleccion_id, s.nombre, c.anio_mundial, " +
                     "c.posesion_prom, c.corners_prom, c.goles_prom, " +
                     "c.precision_pases_pct, c.tiros_prom, c.faltas_prom, " +
                     "c.fase_alcanzada " +
                     "FROM comparativa_historica_tactica c " +
                     "JOIN seleccion_ref s ON s.seleccion_id = c.seleccion_id " +
                     "ORDER BY c.anio_mundial DESC, c.posesion_prom DESC";
        String[] cols = {"ID", "Seleccion", "Anio", "Posesion", "Corners", "Goles",
                         "Prec. Pases", "Tiros", "Faltas", "Fase"};

        panel.add(crearTabla(sql, cols), BorderLayout.CENTER);
        return panel;
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        SwingUtilities.invokeLater(() -> {
            new VentanaPrincipal().setVisible(true);
        });
    }
}
