package proyectofinal.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private ConexionBD() {}

    private static final String URL = "jdbc:postgresql://localhost:5432/mundial?currentSchema=ProyectoFinalBDD";
    private static final String USER = "postgres";
    private static final String PASSWORD = "lionel2019";

    private static Connection conexion;

    public static Connection getConexion() {
        if (conexion == null) {
            try {
                conexion = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Conectado a PostgreSQL - mundial_ms3");
            } catch (SQLException e) {
                System.err.println("Error de conexion: " + e.getMessage());
            }
        }
        return conexion;
    }

    public static void cerrar() {
        if (conexion != null) {
            try {
                conexion.close();
                System.out.println("Conexion cerrada.");
            } catch (SQLException e) {
                System.err.println("Error al cerrar: " + e.getMessage());
            }
        }
    }
}
