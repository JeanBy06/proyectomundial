module proyectofinal {
    requires transitive java.sql;
    requires transitive java.desktop;
    exports proyectofinal.db;
    exports proyectofinal.gui;
}
